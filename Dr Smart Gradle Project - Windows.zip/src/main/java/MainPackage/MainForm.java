/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage;

import CreatedClasses.AppointmentDetails;
import CreatedClasses.CommonMethods;
import CreatedClasses.SendReminderSMS;
import MainPackage.Enum.MBoxButton;
import MainPackage.Enum.MBoxIcon;
import MainPackage.Mbox.MessageBox;
import MainPackage.PopupPanels.Notifications;
import MainPackage.Tabs.Appointment;
import MainPackage.Tabs.Doctors;
import MainPackage.Tabs.Drugs;
import MainPackage.Tabs.GeneratePrescription;
import MainPackage.Tabs.Home;
import MainPackage.Tabs.ManagePatients;
import MainPackage.Tabs.PatientAdmission;
import MainPackage.Tabs.PatientInsurance;
import MainPackage.Tabs.Report;
import MainPackage.Tabs.SearchPatients;
import MainPackage.Tabs.Settings;
import java.awt.AWTException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.Timer;

/**
 *
 * @author Nayanajith
 */
public class MainForm extends javax.swing.JFrame {

    Timer timer;

    TrayIcon trayIcon;
    final SystemTray tray = SystemTray.getSystemTray();

    //this load from login form
    public static LoginForm loginForm;

    //left side panel activated button and loaded panels
    int mouseX, mouseY;
    JLabel activeLabel;
    JPanel loadedPanel;
    JPanel pnlSideTab;

    //create all panels for load
    Doctors doctors;
    ManagePatients managePatients;
    SearchPatients searchPatients;
    Drugs drugs;
    GeneratePrescription generatePrescription;
    Settings settings;
    PatientInsurance patientInsurance;
    Appointment appointment;
    Report report;
    Home home;

    boolean maximized = false;

    //sqlite connection
    static String currentDir = "jdbc:sqlite:" + CommonMethods.DBPath();
    static Connection con = null;
    
    List<Image> images = new ArrayList<>();

    /**
     * Creates new form MainForm
     */
    public MainForm(LoginForm lf) {
        initComponents();

        timer = new Timer(15 * 60 * 1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        NotificationSend();
                    }
                });
                thread.start();
            }
        });

        timer.start();

        //this.setIconImage(new ImageIcon(getClass().getResource("/Logo32.png")).getImage());
        
        images.add(new ImageIcon(getClass().getResource("/Logo16.png")).getImage());
        images.add(new ImageIcon(getClass().getResource("/Logo32.png")).getImage());
        images.add(new ImageIcon(getClass().getResource("/Logo64.png")).getImage());
        images.add(new ImageIcon(getClass().getResource("/Logo128.png")).getImage());
        
        this.setIconImages(images);
        
        //login form set here
        loginForm = lf;

        //load panels initial
        doctors = new Doctors(this);
        managePatients = new ManagePatients(this);
        searchPatients = new SearchPatients(this);
        drugs = new Drugs(this);
        generatePrescription = new GeneratePrescription(this);
        settings = new Settings(this);
        patientInsurance = new PatientInsurance(this);
        appointment = new Appointment(this);
        report = new Report(this);
        home = new Home();

        //load home page when main form loading
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                pnlChildFormLoad.add(home);
                loadedPanel = home;
                pnlSideTab = new JPanel();
                pnlSideTab.setBackground(new Color(0, 200, 207));
                pnlSideTab.setOpaque(true);
            }
        });

        th.start();

        //separate thread for load profile pic and name
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                String username = GetLoggedinUsersUsername();
                if (username != null) {
                    ImageIcon imgIcon = CommonMethods.GetPicByUsername(username);
                    lblLogedInProPic.setIcon(CommonMethods.makeRoundedCorner(imgIcon.getImage(), 60, 60, 255));
                    lblLogedinName.setText(CommonMethods.GetNameByUsername(username));
                }
            }
        });
        thread.start();

        if (SystemTray.isSupported()) {
            AddSystemTrayIcon();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        popupLogout = new javax.swing.JPopupMenu();
        popupNotifications = new javax.swing.JPopupMenu();
        pnlMain = new javax.swing.JPanel();
        pnlChildFormLoad = new javax.swing.JPanel();
        pnlTop = new javax.swing.JPanel();
        lblClose = new javax.swing.JLabel();
        lblMaximize = new javax.swing.JLabel();
        lblMinimize = new javax.swing.JLabel();
        lblCurrentTabIcon = new javax.swing.JLabel();
        lblCurrentTabName = new javax.swing.JLabel();
        pnlProfileDetails = new javax.swing.JPanel();
        lblNotification = new javax.swing.JLabel();
        lblLogedInProPic = new javax.swing.JLabel();
        lblDropDownLogout = new javax.swing.JLabel();
        lblLogedinName = new javax.swing.JLabel();
        pnlLeft = new javax.swing.JPanel();
        pnlLogo = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        lblTitle = new javax.swing.JLabel();
        lblSubTitle = new javax.swing.JLabel();
        pnlButtonTab = new javax.swing.JPanel();
        lblGeneratePrescription = new javax.swing.JLabel();
        lblManagePatients = new javax.swing.JLabel();
        lblSearchPatients = new javax.swing.JLabel();
        lblPatienInsurance = new javax.swing.JLabel();
        lblReport = new javax.swing.JLabel();
        lblDoctors = new javax.swing.JLabel();
        lblSettings = new javax.swing.JLabel();
        lblDrugs = new javax.swing.JLabel();
        lblAppointment = new javax.swing.JLabel();
        pnlShadow = new javax.swing.JPanel();

        popupLogout.setBackground(new java.awt.Color(255, 255, 255));
        popupLogout.setBorder(null);
        popupLogout.setPreferredSize(null);

        popupNotifications.setBackground(new java.awt.Color(255, 255, 255));
        popupNotifications.setBorder(null);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1300, 750));
        setUndecorated(true);
        setSize(new java.awt.Dimension(1300, 750));

        pnlMain.setBackground(new java.awt.Color(34, 33, 74));
        pnlMain.setPreferredSize(new java.awt.Dimension(0, 0));
        pnlMain.setLayout(new java.awt.GridBagLayout());

        pnlChildFormLoad.setBackground(new java.awt.Color(255, 255, 255));
        pnlChildFormLoad.setPreferredSize(new java.awt.Dimension(100, 100));
        pnlChildFormLoad.setLayout(new javax.swing.BoxLayout(pnlChildFormLoad, javax.swing.BoxLayout.LINE_AXIS));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        pnlMain.add(pnlChildFormLoad, gridBagConstraints);

        pnlTop.setBackground(new java.awt.Color(27, 27, 62));
        pnlTop.setMaximumSize(new java.awt.Dimension(1000, 120));
        pnlTop.setMinimumSize(new java.awt.Dimension(1000, 120));
        pnlTop.setPreferredSize(new java.awt.Dimension(1000, 120));
        pnlTop.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                pnlTopMouseDragged(evt);
            }
        });
        pnlTop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pnlTopMousePressed(evt);
            }
        });

        lblClose.setBackground(new java.awt.Color(27, 27, 62));
        lblClose.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblClose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CloseWhiteSmall.png"))); // NOI18N
        lblClose.setOpaque(true);
        lblClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCloseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCloseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCloseMouseExited(evt);
            }
        });

        lblMaximize.setBackground(new java.awt.Color(27, 27, 62));
        lblMaximize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMaximize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ToMaximize.png"))); // NOI18N
        lblMaximize.setOpaque(true);
        lblMaximize.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMaximizeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblMaximizeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblMaximizeMouseExited(evt);
            }
        });

        lblMinimize.setBackground(new java.awt.Color(27, 27, 62));
        lblMinimize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMinimize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Minimize.png"))); // NOI18N
        lblMinimize.setOpaque(true);
        lblMinimize.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMinimizeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblMinimizeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblMinimizeMouseExited(evt);
            }
        });

        lblCurrentTabIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Home.png"))); // NOI18N

        lblCurrentTabName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblCurrentTabName.setForeground(new java.awt.Color(255, 255, 255));
        lblCurrentTabName.setText("Home");

        pnlProfileDetails.setBackground(new java.awt.Color(102, 102, 102));
        pnlProfileDetails.setOpaque(false);
        pnlProfileDetails.setLayout(new java.awt.GridBagLayout());

        lblNotification.setBackground(new java.awt.Color(0, 204, 0));
        lblNotification.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Notification.png"))); // NOI18N
        lblNotification.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblNotificationMouseClicked(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 10, 0, 0);
        pnlProfileDetails.add(lblNotification, gridBagConstraints);

        lblLogedInProPic.setBackground(new java.awt.Color(51, 51, 51));
        lblLogedInProPic.setMinimumSize(new java.awt.Dimension(60, 60));
        lblLogedInProPic.setPreferredSize(new java.awt.Dimension(60, 60));
        lblLogedInProPic.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 10, 0, 0);
        pnlProfileDetails.add(lblLogedInProPic, gridBagConstraints);

        lblDropDownLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/DropDownMenu.png"))); // NOI18N
        lblDropDownLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDropDownLogoutMouseClicked(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 10, 0, 0);
        pnlProfileDetails.add(lblDropDownLogout, gridBagConstraints);

        lblLogedinName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblLogedinName.setForeground(new java.awt.Color(255, 255, 255));
        lblLogedinName.setMinimumSize(new java.awt.Dimension(180, 16));
        lblLogedinName.setPreferredSize(new java.awt.Dimension(180, 16));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 10, 0, 0);
        pnlProfileDetails.add(lblLogedinName, gridBagConstraints);

        javax.swing.GroupLayout pnlTopLayout = new javax.swing.GroupLayout(pnlTop);
        pnlTop.setLayout(pnlTopLayout);
        pnlTopLayout.setHorizontalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurrentTabIcon)
                .addGap(16, 16, 16)
                .addComponent(lblCurrentTabName, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 258, Short.MAX_VALUE)
                .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTopLayout.createSequentialGroup()
                        .addComponent(lblMinimize, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(lblMaximize, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(lblClose, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTopLayout.createSequentialGroup()
                        .addComponent(pnlProfileDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        pnlTopLayout.setVerticalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCurrentTabIcon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblCurrentTabName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblClose, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMaximize, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMinimize, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlProfileDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        pnlMain.add(pnlTop, gridBagConstraints);

        pnlLeft.setBackground(new java.awt.Color(32, 31, 70));
        pnlLeft.setPreferredSize(new java.awt.Dimension(300, 0));
        pnlLeft.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlLogo.setMinimumSize(new java.awt.Dimension(300, 100));
        pnlLogo.setOpaque(false);
        pnlLogo.setPreferredSize(new java.awt.Dimension(0, 0));
        pnlLogo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlLogoMouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Logo.png"))); // NOI18N
        pnlLogo.add(jLabel3);

        lblTitle.setFont(new java.awt.Font("Raleway", 0, 30));
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("DR.SMART");
        lblTitle.setPreferredSize(new java.awt.Dimension(173, 50));
        pnlLogo.add(lblTitle);

        lblSubTitle.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblSubTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblSubTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSubTitle.setText("INNOVATION IN HEALTH CARE");
        pnlLogo.add(lblSubTitle);

        pnlLeft.add(pnlLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 210));

        pnlButtonTab.setOpaque(false);
        pnlButtonTab.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblGeneratePrescription.setBackground(new java.awt.Color(32, 31, 70));
        lblGeneratePrescription.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblGeneratePrescription.setForeground(new java.awt.Color(255, 255, 255));
        lblGeneratePrescription.setIcon(new javax.swing.ImageIcon(getClass().getResource("/GeneratePrescription.png"))); // NOI18N
        lblGeneratePrescription.setText("Generate Prescription");
        lblGeneratePrescription.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblGeneratePrescription.setIconTextGap(10);
        lblGeneratePrescription.setMaximumSize(new java.awt.Dimension(292, 50));
        lblGeneratePrescription.setMinimumSize(new java.awt.Dimension(292, 50));
        lblGeneratePrescription.setOpaque(true);
        lblGeneratePrescription.setPreferredSize(new java.awt.Dimension(292, 50));
        lblGeneratePrescription.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGeneratePrescriptionMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblGeneratePrescription, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 0, 292, 50));

        lblManagePatients.setBackground(new java.awt.Color(32, 31, 70));
        lblManagePatients.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblManagePatients.setForeground(new java.awt.Color(255, 255, 255));
        lblManagePatients.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Patient.png"))); // NOI18N
        lblManagePatients.setText("Manage Patients");
        lblManagePatients.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblManagePatients.setIconTextGap(10);
        lblManagePatients.setMaximumSize(new java.awt.Dimension(292, 50));
        lblManagePatients.setMinimumSize(new java.awt.Dimension(292, 50));
        lblManagePatients.setOpaque(true);
        lblManagePatients.setPreferredSize(new java.awt.Dimension(292, 50));
        lblManagePatients.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblManagePatientsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblManagePatients, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 50, 292, 50));

        lblSearchPatients.setBackground(new java.awt.Color(32, 31, 70));
        lblSearchPatients.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblSearchPatients.setForeground(new java.awt.Color(255, 255, 255));
        lblSearchPatients.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SearchPatient.png"))); // NOI18N
        lblSearchPatients.setText("Search Patients");
        lblSearchPatients.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblSearchPatients.setIconTextGap(10);
        lblSearchPatients.setMinimumSize(new java.awt.Dimension(292, 50));
        lblSearchPatients.setOpaque(true);
        lblSearchPatients.setPreferredSize(new java.awt.Dimension(292, 50));
        lblSearchPatients.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSearchPatientsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblSearchPatients, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 100, 292, 50));

        lblPatienInsurance.setBackground(new java.awt.Color(32, 31, 70));
        lblPatienInsurance.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblPatienInsurance.setForeground(new java.awt.Color(255, 255, 255));
        lblPatienInsurance.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Insurance.png"))); // NOI18N
        lblPatienInsurance.setText("Patient Insurance");
        lblPatienInsurance.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblPatienInsurance.setIconTextGap(10);
        lblPatienInsurance.setMinimumSize(new java.awt.Dimension(292, 50));
        lblPatienInsurance.setOpaque(true);
        lblPatienInsurance.setPreferredSize(new java.awt.Dimension(292, 50));
        lblPatienInsurance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPatienInsuranceMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblPatienInsurance, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 150, 292, 50));

        lblReport.setBackground(new java.awt.Color(32, 31, 70));
        lblReport.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblReport.setForeground(new java.awt.Color(255, 255, 255));
        lblReport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Report.png"))); // NOI18N
        lblReport.setText("Report");
        lblReport.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblReport.setIconTextGap(10);
        lblReport.setMinimumSize(new java.awt.Dimension(292, 50));
        lblReport.setOpaque(true);
        lblReport.setPreferredSize(new java.awt.Dimension(292, 50));
        lblReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblReportMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 200, 292, 50));

        lblDoctors.setBackground(new java.awt.Color(32, 31, 70));
        lblDoctors.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblDoctors.setForeground(new java.awt.Color(255, 255, 255));
        lblDoctors.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Doctor.png"))); // NOI18N
        lblDoctors.setText("Doctors");
        lblDoctors.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblDoctors.setIconTextGap(10);
        lblDoctors.setMinimumSize(new java.awt.Dimension(292, 50));
        lblDoctors.setOpaque(true);
        lblDoctors.setPreferredSize(new java.awt.Dimension(292, 50));
        lblDoctors.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDoctorsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblDoctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 250, 292, 50));

        lblSettings.setBackground(new java.awt.Color(32, 31, 70));
        lblSettings.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblSettings.setForeground(new java.awt.Color(255, 255, 255));
        lblSettings.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Settings.png"))); // NOI18N
        lblSettings.setText("Settings");
        lblSettings.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblSettings.setIconTextGap(10);
        lblSettings.setMinimumSize(new java.awt.Dimension(292, 50));
        lblSettings.setOpaque(true);
        lblSettings.setPreferredSize(new java.awt.Dimension(292, 50));
        lblSettings.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSettingsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblSettings, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 400, 292, 50));

        lblDrugs.setBackground(new java.awt.Color(32, 31, 70));
        lblDrugs.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblDrugs.setForeground(new java.awt.Color(255, 255, 255));
        lblDrugs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Drugs.png"))); // NOI18N
        lblDrugs.setText("Drugs and Tests");
        lblDrugs.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblDrugs.setIconTextGap(10);
        lblDrugs.setMinimumSize(new java.awt.Dimension(292, 50));
        lblDrugs.setOpaque(true);
        lblDrugs.setPreferredSize(new java.awt.Dimension(292, 50));
        lblDrugs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDrugsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblDrugs, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 300, 292, 50));

        lblAppointment.setBackground(new java.awt.Color(32, 31, 70));
        lblAppointment.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblAppointment.setForeground(new java.awt.Color(255, 255, 255));
        lblAppointment.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Appointment.png"))); // NOI18N
        lblAppointment.setText("Appointment");
        lblAppointment.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 0));
        lblAppointment.setIconTextGap(10);
        lblAppointment.setMinimumSize(new java.awt.Dimension(292, 50));
        lblAppointment.setOpaque(true);
        lblAppointment.setPreferredSize(new java.awt.Dimension(292, 50));
        lblAppointment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAppointmentMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TabButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TabButtonMouseExited(evt);
            }
        });
        pnlButtonTab.add(lblAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 350, 292, 50));

        pnlLeft.add(pnlButtonTab, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 300, 510));

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weighty = 1.0;
        pnlMain.add(pnlLeft, gridBagConstraints);

        pnlShadow.setBackground(new java.awt.Color(23, 23, 57));
        pnlShadow.setPreferredSize(new java.awt.Dimension(1000, 8));

        javax.swing.GroupLayout pnlShadowLayout = new javax.swing.GroupLayout(pnlShadow);
        pnlShadow.setLayout(pnlShadowLayout);
        pnlShadowLayout.setHorizontalGroup(
            pnlShadowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pnlShadowLayout.setVerticalGroup(
            pnlShadowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 1000;
        gridBagConstraints.ipady = 5;
        pnlMain.add(pnlShadow, gridBagConstraints);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, 1310, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, 750, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    // <editor-fold defaultstate="collapsed" desc="Form Control">
    private void pnlTopMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlTopMousePressed
        mouseX = evt.getX();
        mouseY = evt.getY();
    }//GEN-LAST:event_pnlTopMousePressed

    private void pnlTopMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlTopMouseDragged
        if (!maximized) {
            this.setLocation(this.getX() + evt.getX() - mouseX, this.getY() + evt.getY() - mouseY);
        }
    }//GEN-LAST:event_pnlTopMouseDragged

    private void lblCloseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCloseMouseEntered
        lblClose.setBackground(new Color(232, 17, 35));
    }//GEN-LAST:event_lblCloseMouseEntered

    private void lblCloseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCloseMouseExited
        lblClose.setBackground(new Color(27, 27, 62));
    }//GEN-LAST:event_lblCloseMouseExited

    private void lblMaximizeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMaximizeMouseEntered
        lblMaximize.setBackground(new Color(37, 37, 72));
    }//GEN-LAST:event_lblMaximizeMouseEntered

    private void lblMaximizeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMaximizeMouseExited
        lblMaximize.setBackground(new Color(27, 27, 62));
    }//GEN-LAST:event_lblMaximizeMouseExited

    private void lblMinimizeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMinimizeMouseEntered
        lblMinimize.setBackground(new Color(37, 37, 72));
    }//GEN-LAST:event_lblMinimizeMouseEntered

    private void lblMinimizeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMinimizeMouseExited
        lblMinimize.setBackground(new Color(27, 27, 62));
    }//GEN-LAST:event_lblMinimizeMouseExited

    private void lblCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCloseMouseClicked
        if (SystemTray.isSupported()) {
            this.setVisible(false);
            try {
                trayIcon.displayMessage("Message", "Dr. Smart running in background.", TrayIcon.MessageType.INFO);
            } catch (Exception e) {
            }
        } else {
            System.exit(0);
        }
    }//GEN-LAST:event_lblCloseMouseClicked

    private void lblMaximizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMaximizeMouseClicked
        if (maximized) {
            this.setExtendedState(this.NORMAL); 
            maximized = false;
            lblMaximize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ToMaximize.png")));
        } else {
            this.setExtendedState(this.getExtendedState() | this.MAXIMIZED_BOTH);
            maximized = true;
            lblMaximize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ToNormal.png")));
        }
    }//GEN-LAST:event_lblMaximizeMouseClicked

    private void lblMinimizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMinimizeMouseClicked
        this.setState(this.ICONIFIED);
    }//GEN-LAST:event_lblMinimizeMouseClicked

    //</editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Tab Button and Form Load">
    private void TabButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabButtonMouseEntered
        JLabel mouseHoverLabel = (JLabel) evt.getComponent();

        if (activeLabel != null) {
            if (!activeLabel.equals(mouseHoverLabel)) {
                mouseHoverLabel.setBackground(new Color(42, 41, 80));
            }
        } else {
            mouseHoverLabel.setBackground(new Color(42, 41, 80));
        }
    }//GEN-LAST:event_TabButtonMouseEntered

    private void TabButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabButtonMouseExited
        JLabel mouseHoverLabel = (JLabel) evt.getComponent();

        if (activeLabel != null) {
            if (!activeLabel.equals(mouseHoverLabel)) {
                mouseHoverLabel.setBackground(new Color(32, 31, 70));
            }
        } else {
            mouseHoverLabel.setBackground(new Color(32, 31, 70));
        }
    }//GEN-LAST:event_TabButtonMouseExited

    private void lblGeneratePrescriptionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGeneratePrescriptionMouseClicked
        if (generatePrescription == null) {
            generatePrescription = new GeneratePrescription(this);
        }

        childPanelLoad(evt, generatePrescription);
    }//GEN-LAST:event_lblGeneratePrescriptionMouseClicked

    private void lblManagePatientsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblManagePatientsMouseClicked
        if (managePatients == null) {
            managePatients = new ManagePatients(this);
        }

        childPanelLoad(evt, managePatients);
    }//GEN-LAST:event_lblManagePatientsMouseClicked

    private void lblSearchPatientsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSearchPatientsMouseClicked
        if (searchPatients == null) {
            searchPatients = new SearchPatients(this);
        }

        childPanelLoad(evt, searchPatients);
    }//GEN-LAST:event_lblSearchPatientsMouseClicked

    private void lblPatienInsuranceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPatienInsuranceMouseClicked
        if (patientInsurance == null) {
            patientInsurance = new PatientInsurance(this);
        }

        childPanelLoad(evt, patientInsurance);
    }//GEN-LAST:event_lblPatienInsuranceMouseClicked

    private void lblReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReportMouseClicked
        if (report == null) {
            report = new Report(this);
        }

        childPanelLoad(evt, report);
    }//GEN-LAST:event_lblReportMouseClicked

    private void lblDoctorsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDoctorsMouseClicked
        if (doctors == null) {
            doctors = new Doctors(this);
        }

        childPanelLoad(evt, doctors);
    }//GEN-LAST:event_lblDoctorsMouseClicked

    private void lblSettingsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSettingsMouseClicked
        if (settings == null) {
            settings = new Settings(this);
        }

        childPanelLoad(evt, settings);
    }//GEN-LAST:event_lblSettingsMouseClicked

    private void lblDrugsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDrugsMouseClicked
        if (drugs == null) {
            drugs = new Drugs(this);
        }

        childPanelLoad(evt, drugs);
    }//GEN-LAST:event_lblDrugsMouseClicked

    private void lblAppointmentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAppointmentMouseClicked
        if (appointment == null) {
            appointment = new Appointment(this);
        }

        childPanelLoad(evt, appointment);
    }//GEN-LAST:event_lblAppointmentMouseClicked

    private void pnlLogoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlLogoMouseClicked
        pnlChildFormLoad.removeAll();
        pnlChildFormLoad.add(home);
        loadedPanel = home;

        if (activeLabel != null) {
            activeLabel.setBackground(new Color(32, 31, 70));
        }

        pnlButtonTab.remove(pnlSideTab);
        lblCurrentTabIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Home.png")));
        lblCurrentTabName.setText("Home");
        this.revalidate();
        this.repaint();
    }//GEN-LAST:event_pnlLogoMouseClicked

    private void childPanelLoad(java.awt.event.MouseEvent evt, JPanel childPanel) {
        JLabel clickedLabel = (JLabel) evt.getComponent();

        if (loadedPanel instanceof Home) {
            if (activeLabel != null) {
                activeLabel.setBackground(new Color(32, 31, 70));
            }

            clickedLabel.setBackground(new Color(1, 160, 192, 50));
            SetSideTab(clickedLabel);

            lblCurrentTabIcon.setIcon(clickedLabel.getIcon());
            lblCurrentTabName.setText(clickedLabel.getText());

            pnlChildFormLoad.removeAll();
            activeLabel = clickedLabel;
            loadedPanel = childPanel;

            pnlChildFormLoad.add(childPanel);
            this.revalidate();
            this.repaint();
        } else {
            if (activeLabel != null && activeLabel.equals(clickedLabel)) {
                return;
            }

            if (activeLabel != null) {
                activeLabel.setBackground(new Color(32, 31, 70));
            }

            clickedLabel.setBackground(new Color(1, 160, 192, 50));
            SetSideTab(clickedLabel);

            lblCurrentTabIcon.setIcon(clickedLabel.getIcon());
            lblCurrentTabName.setText(clickedLabel.getText());

            pnlSideTab.setAlignmentX(0);
            pnlSideTab.setAlignmentY(50);

            pnlChildFormLoad.removeAll();
            activeLabel = clickedLabel;
            loadedPanel = childPanel;

            pnlChildFormLoad.add(childPanel);
            this.revalidate();
            this.repaint();
        }
    }

    private void SetSideTab(JLabel clickedLabel) {
        pnlButtonTab.remove(pnlSideTab);
        AbsoluteConstraints ac = new AbsoluteConstraints(0, GetJLabelY(clickedLabel) * 50, 8, 50);
        pnlButtonTab.add(pnlSideTab, ac);
    }

    private int GetJLabelY(JLabel lbl) {

        if (lbl.equals(lblGeneratePrescription)) {
            return 0;
        } else if (lbl.equals(lblManagePatients)) {
            return 1;
        } else if (lbl.equals(lblSearchPatients)) {
            return 2;
        } else if (lbl.equals(lblPatienInsurance)) {
            return 3;
            //} else if (lbl.equals(lblPatientAdmisson)) {
            //    return 4;
        } else if (lbl.equals(lblReport)) {
            return 4;
        } else if (lbl.equals(lblDoctors)) {
            return 5;
        } else if (lbl.equals(lblDrugs)) {
            return 6;
        } else if (lbl.equals(lblAppointment)) {
            return 7;
        } else {
            return 8;
        }
    }

    //</editor-fold>
    
    //click down arrow for logout
    private void lblDropDownLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDropDownLogoutMouseClicked
        JMenuItem logoutItm = new JMenuItem("Log Out", new ImageIcon(getClass().getResource("/Logout.png")));
        logoutItm.setBackground(Color.white);
        logoutItm.setOpaque(true);
        logoutItm.setFont(new Font("Tahoma", Font.PLAIN, 13));
        logoutItm.setBorder(new EmptyBorder(5, 15, 5, 15));

        logoutItm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Logout();
            }
        });

        popupLogout.removeAll();
        popupLogout.add(logoutItm);
        popupLogout.show(lblDropDownLogout, 0, lblDropDownLogout.getHeight());
    }//GEN-LAST:event_lblDropDownLogoutMouseClicked

    //notification icon click
    private void lblNotificationMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNotificationMouseClicked
        Notifications notifi = new Notifications();

        popupNotifications.removeAll();
        popupNotifications.add(notifi);
        popupNotifications.show(lblNotification, 0, lblNotification.getHeight());
    }//GEN-LAST:event_lblNotificationMouseClicked

    //logot method - this dipose and set visible true of previous login form
    private void Logout() {
        tray.remove(trayIcon);
        loginForm.txtPassword.setText("");
        loginForm.setVisible(true);
        this.dispose();
    }

    //for get login username
    private static String GetLoggedinUsersUsername() {
        Statement statement = null;
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();
            ResultSet result = statement.executeQuery("SELECT username FROM loggedin_user WHERE id = 1");

            result.next();
            return result.getString(1);

        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }

    public void LoadAddPatient(String patientID) {
        JLabel clickedLabel = lblManagePatients;
        managePatients.LoadAddPatientPanelWithPatientID(patientID);

        if (activeLabel != null && activeLabel.equals(clickedLabel)) {
            return;
        }

        if (activeLabel != null) {
            activeLabel.setBackground(new Color(32, 31, 70));
        }

        clickedLabel.setBackground(new Color(1, 160, 192, 50));
        SetSideTab(clickedLabel);

        lblCurrentTabIcon.setIcon(clickedLabel.getIcon());
        lblCurrentTabName.setText(clickedLabel.getText());

        pnlSideTab.setAlignmentX(0);
        pnlSideTab.setAlignmentY(50);

        pnlChildFormLoad.removeAll();
        activeLabel = clickedLabel;
        loadedPanel = managePatients;

        pnlChildFormLoad.add(managePatients);
        this.revalidate();
        this.repaint();
    }

    private void AddSystemTrayIcon() {
        Image image = (new ImageIcon(getClass().getResource("/LogoVerySmall.png"))).getImage();

        final PopupMenu popup = new PopupMenu();
        trayIcon = new TrayIcon(image, "Dr. Smart", popup);

        MenuItem exitItem = new MenuItem("Exit");
        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        MenuItem openItem = new MenuItem("Open");
        openItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Show();
            }
        });

        popup.add(openItem);
        popup.addSeparator();
        popup.add(exitItem);

        trayIcon.setPopupMenu(popup);

        try {
            tray.add(trayIcon);
        } catch (AWTException e) {
            System.out.println("TrayIcon could not be added.");
        }
    }

    private void Show() {
        this.setVisible(true);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm(loginForm).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel lblAppointment;
    private javax.swing.JLabel lblClose;
    private javax.swing.JLabel lblCurrentTabIcon;
    private javax.swing.JLabel lblCurrentTabName;
    private javax.swing.JLabel lblDoctors;
    private javax.swing.JLabel lblDropDownLogout;
    private javax.swing.JLabel lblDrugs;
    private javax.swing.JLabel lblGeneratePrescription;
    private javax.swing.JLabel lblLogedInProPic;
    private javax.swing.JLabel lblLogedinName;
    private javax.swing.JLabel lblManagePatients;
    private javax.swing.JLabel lblMaximize;
    private javax.swing.JLabel lblMinimize;
    private javax.swing.JLabel lblNotification;
    private javax.swing.JLabel lblPatienInsurance;
    private javax.swing.JLabel lblReport;
    private javax.swing.JLabel lblSearchPatients;
    private javax.swing.JLabel lblSettings;
    private javax.swing.JLabel lblSubTitle;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlButtonTab;
    private javax.swing.JPanel pnlChildFormLoad;
    private javax.swing.JPanel pnlLeft;
    private javax.swing.JPanel pnlLogo;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JPanel pnlProfileDetails;
    private javax.swing.JPanel pnlShadow;
    private javax.swing.JPanel pnlTop;
    private javax.swing.JPopupMenu popupLogout;
    private javax.swing.JPopupMenu popupNotifications;
    // End of variables declaration//GEN-END:variables

    //================================================Email Notification System================================================//
    List<AppointmentDetails> ad;

    private void NotificationSend() {

        System.out.println("call notification");

        if (CommonMethods.EmailNotifiIsOn()) {
            ad = CommonMethods.GetTodayAppointments();

            if (ad.toArray().length > 0) {
                for (AppointmentDetails a : ad) {
                    if (a.PatientEmail != null && !a.PatientEmail.equals("")) {
                        if (CommonMethods.SendEmail(a.PatientEmail, "Reminder of the Appointment", String.format("Dear %s,\nPlease note that today(%s) you have made an appointment to meet Dr. %s at %s", a.PatientName, a.AppointmentDate, a.DoctorName, a.ApointmentTime))) {
                            SetSentReminder(a.AppointmentID);
                            appointment.LoadDetails();
                            CommonMethods.AddNotification(String.format("Dr. %s, Today(%s) you have to meet %s at %s", a.DoctorName, a.AppointmentDate, a.PatientName, a.ApointmentTime));
                        }
                    }
                }
            }
        } else if (CommonMethods.SMSNotifiIsOn()) {
            System.out.println("send sms call");

            ad = CommonMethods.GetTodayAppointments();

            if (ad.toArray().length > 0) {
                for (AppointmentDetails a : ad) {
                    if (a.PhoneNumber != null && !a.PhoneNumber.equals("")) {
                        try {
                            if (SendReminderSMS.Send(a.PhoneNumber, String.format("Dear %s,\nPlease note that today(%s) you have made an appointment to meet Dr. %s at %s", a.PatientName, a.AppointmentDate, a.DoctorName, a.ApointmentTime))) {
                                SetSentReminder(a.AppointmentID);
                                appointment.LoadDetails();
                                CommonMethods.AddNotification(String.format("Dr. %s, Today(%s) you have to meet %s at %s", a.DoctorName, a.AppointmentDate, a.PatientName, a.ApointmentTime));
                            }
                        } catch (Exception e) {
                        }
                    }
                }
            }
        }
    }

    public void SetSentReminder(int appointmentID) {
        Statement statement = null;

        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();
            statement.executeUpdate(String.format("UPDATE appointments SET send_reminder = 'Yes' WHERE id = %s", appointmentID));
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
}
