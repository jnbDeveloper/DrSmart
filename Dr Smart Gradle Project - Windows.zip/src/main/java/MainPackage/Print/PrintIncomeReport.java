/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage.Print;

import CreatedClasses.Doctor;
import CreatedClasses.InvoiceItem;
import CreatedClasses.Patient;
import CreatedClasses.PrescriptionItem;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import static java.awt.SystemColor.text;
import java.awt.font.FontRenderContext;
import java.awt.font.LineBreakMeasurer;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nayanajith
 */
public class PrintIncomeReport implements Printable {

    public Image pic = (new javax.swing.ImageIcon(getClass().getResource("/DefaultHospitalLogo.png"))).getImage();
    public Image emailPic = (new javax.swing.ImageIcon(getClass().getResource("/Email.png"))).getImage();
    public Image phonePic = (new javax.swing.ImageIcon(getClass().getResource("/Phone.png"))).getImage();

    public String reportTitle = "";
    
    public String medicalCenterName = "";
    public String medicalCenterAddress = "";
    public String medicalCenterPhoneNumber = "";
    public String medicalCenterEmail = "";

    public Doctor doc;
    public String date = "";
    public String time = "";
    
    public String totalPatientCheck = "";
    public String totalInvoices = "";
    public String totalIncome = "";

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        pageFormat.setOrientation(PageFormat.PORTRAIT);

        if (pageIndex > 0) {
            return Printable.NO_SUCH_PAGE;
        }
        int iX = (int) pageFormat.getImageableX() + 1;
        int iY = (int) pageFormat.getImageableY() + 1;

        int iWidth = (int) pageFormat.getImageableWidth() - 2;
        int iHeight = (int) pageFormat.getImageableHeight() - 2;

        Font titleFont = new Font("Orbitron", Font.BOLD, 20);
        Font subFont = new Font("Monospaced", Font.PLAIN, 10);
        Font subBoldFont = new Font("Monospaced", Font.BOLD, 10);

        Color lineColor = new Color(180, 180, 180);

        Graphics2D g2 = (Graphics2D) graphics;

        //set black color
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke((float) 0.1));

        // <editor-fold defaultstate="collapsed" desc="Parmacy Part">
        int y = iY;

        int defaultLineHeight = GetStringDimention(graphics, subFont, "ABCabc123").height;

        //draw logo
        g2.drawImage(pic, iX, y + 10, 40, 40, null);

        //draw medical center name
        y += GetStringDimention(graphics, titleFont, medicalCenterName).height;
        g2.setFont(titleFont);
        g2.drawString(medicalCenterName, iX + 55, y);

        //medical center address
        g2.setFont(subFont);

        for (String line : medicalCenterAddress.split("\n")) {
            g2.drawString(line, iX + 55, y += defaultLineHeight);
        }

        //draw medical center phone number
        g2.drawString(medicalCenterPhoneNumber, iX + 55, y += defaultLineHeight);

        //draw medical center phone number
        g2.drawString(medicalCenterEmail, iX + 55, y += defaultLineHeight);

        y += 30;
        g2.setFont(subBoldFont);
        //draw title
        g2.drawString(reportTitle, iX + (iWidth / 2) - (GetStringDimention(graphics, subFont, reportTitle).width / 2), y);
        
        g2.setFont(subFont);
        y += 30;

        int leftAlign = iX + GetStringDimention(graphics, subFont, "Doctor Reg. No. : ").width + 10;

        if (doc != null) {
            //draw patientID
            g2.drawString("Doctor Reg. No.", iX, y += (defaultLineHeight + 3));
            g2.drawString(": " + doc.DoctorID, leftAlign, y);

            //draw patientID
            g2.drawString("Doctor Name", iX, y += (defaultLineHeight + 3));
            g2.drawString(": " + doc.DoctorName, leftAlign, y);
        }
        
        y += 30;
        
        //leftAlign = iX + GetStringDimention(graphics, subFont, "Total Patient Check : ").width + 10;
        
        //draw details
        g2.drawString("Total Patient Check", iX, y);
        g2.drawString(": " + totalPatientCheck, leftAlign, y);
        
        g2.drawString("Total Invoices", iX, y + defaultLineHeight);
        g2.drawString(": " + totalInvoices, leftAlign, y += defaultLineHeight);
        
        g2.drawString("Total Income", iX, y + defaultLineHeight);
        g2.drawString(": " + totalIncome, leftAlign, y += defaultLineHeight);

        //draw date time
        g2.drawString(date, (iX + iWidth) - GetStringDimention(graphics, subFont, date).width, iY + defaultLineHeight);
        g2.drawString(time, (iX + iWidth) - GetStringDimention(graphics, subFont, time).width, iY + (defaultLineHeight * 2));

        g2.drawString("  Checked By  ", (iX + iWidth) - GetStringDimention(graphics, subFont, "  Checked By  ").width - 1, iY + iHeight - 10);
        g2.drawString("------------------", (iX + iWidth) - GetStringDimention(graphics, subFont, "  Checked By  ").width - 10, iY + iHeight - 18);
        // </editor-fold>

        g2.dispose();
        return Printable.PAGE_EXISTS;
    }

    private Dimension GetStringDimention(Graphics g, Font font, String text) {
        FontMetrics metrics = g.getFontMetrics(font);
        return new Dimension(metrics.stringWidth(text), metrics.getHeight());
    }

    private void drawCenteredString(Graphics g, String text, Rectangle rect, Font font) {
        FontMetrics metrics = g.getFontMetrics(font);
        int x = rect.x + (rect.width - metrics.stringWidth(text)) / 2;
        int y = rect.y + ((rect.height - metrics.getHeight()) / 2) + metrics.getAscent();
        g.setFont(font);
        g.drawString(text, x, y);
    }

    private int getAscent(Graphics g, Font font, String text) {
        FontMetrics metrics = g.getFontMetrics(font);
        return metrics.getAscent();
    }
}
