/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage.Print;

import CreatedClasses.PrescriptionItem;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import static java.awt.SystemColor.text;
import java.awt.font.FontRenderContext;
import java.awt.font.LineBreakMeasurer;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nayanajith
 */
public class PrintPrescription implements Printable{
   
    public Image pic = (new javax.swing.ImageIcon(getClass().getResource("/DefaultHospitalLogo.png"))).getImage();
    public Image emailPic = (new javax.swing.ImageIcon(getClass().getResource("/Email.png"))).getImage();
    public Image phonePic = (new javax.swing.ImageIcon(getClass().getResource("/Phone.png"))).getImage();
    
    public String medicalCenterName = "";
    public String docRegID = "";
    public String docName = "";
    public String docEmail = "";
    public String docPhone = "";
    
    public String date = "";
    public String time = "";
    
    public String patientID = "";
    public String patientName = "";
    
    public String specialNote = "";
    
    public String RefNo = "";
    
    public List<PrescriptionItem> presItems;
    
    public List<String> otherRequ;
    
    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        pageFormat.setOrientation(PageFormat.PORTRAIT);
             
        if(pageIndex > 0){
            return Printable.NO_SUCH_PAGE;
        }
        int iX = (int)pageFormat.getImageableX() + 1;
        int iY = (int)pageFormat.getImageableY() + 1;
        
        int iWidth = (int)pageFormat.getImageableWidth() - 2;
        int iHeight = (int)pageFormat.getImageableHeight() - 2;
        
        Font titleFont = new Font("Orbitron", Font.BOLD, 20);
        Font subFont = new Font("Monospaced", Font.PLAIN, 10);
        
        Graphics2D g2 = (Graphics2D)graphics;
        
        //draw center line
        g2.setColor(Color.black);
        //g2.drawLine(iX + (iWidth / 2), iY, iX + (iWidth / 2), iY + iHeight); //vertical
        g2.drawLine(iX, iY + (iHeight / 2), iX + iWidth, iY + (iHeight / 2)); //horizontal
        
        // <editor-fold defaultstate="collapsed" desc="Parmacy Part">
        //draw logo
        g2.drawImage(pic, iX, iY + 10, 40, 40, null);
        
        int y = iY;
        
        //draw medical center name
        y += GetStringDimention(graphics, titleFont, medicalCenterName).height;
        g2.setFont(titleFont);
        g2.drawString(medicalCenterName, iX + 55, y);
        
        
        //draw doctor id + name
        y += GetStringDimention(graphics, subFont, docRegID).height;
        g2.setFont(subFont);
        g2.drawString(docRegID + " | " + docName, iX + 55, y);
        

        //draw phone image and phone number
        y += GetStringDimention(graphics, subFont, docPhone).height;
        g2.drawImage(phonePic, iX + 55, y - 8, 10, 10, null);
        g2.drawString(docPhone, iX + 55 + 12, y);
        
        //draw email image and email
        g2.drawImage(emailPic, iX + 55 + 12 + GetStringDimention(graphics, subFont, docPhone).width + 5, y - 8, 10, 10, null);
        g2.drawString(docEmail, iX + 55 + 12 + GetStringDimention(graphics, subFont, docPhone).width + 5 + 12, y);
        
        int oneLineHeight = GetStringDimention(graphics, subFont, "Ab01").height;
        //draw ref
        g2.drawString(RefNo, (iX + iWidth) - GetStringDimention(graphics, subFont, RefNo).width, iY + oneLineHeight);
        
        //draw date time
        g2.drawString(date + "  " +  time, (iX + iWidth) - GetStringDimention(graphics, subFont, date + "  " +  time).width, iY + (oneLineHeight * 2));
        
        //draw patient details
        g2.drawString(patientID + "  " + patientName, (iX + iWidth) - GetStringDimention(graphics, subFont, patientID + "  " + patientName).width, iY + (oneLineHeight * 3));
        
        //draw headers
        y += 30;
        int drugNameStart = iX + 15;
        int scheduleStart = (iX + iWidth) - GetStringDimention(graphics, subFont, "52mg Every 8 hours  Before  Meal Days").width;
        int relationStart = (iX + iWidth) - GetStringDimention(graphics, subFont, "Before Meal  Days").width;
        int daysStart = (iX + iWidth) - GetStringDimention(graphics, subFont, "Days").width;
        
        g2.drawString("Drug Name", drugNameStart, y);
        g2.drawString("Schedule", scheduleStart, y);
        g2.drawString("D/M Rlt", relationStart, y);
        g2.drawString("Days", daysStart, y);
        
        //draw header line
        y += GetStringDimention(graphics, subFont, "Drug Name").height;
        g2.drawString("----------------------------------------------------------------------------------------------------------------------", iX, y);
         
        //draw prescription items
        int drugNameMaxWidth = iWidth - GetStringDimention(graphics, subFont, "52mg Every 8 hours  Before Meal  Days").width - 20;
        
        if (presItems != null) {
            int count = 1;
            for (PrescriptionItem pti : presItems) {

                int yForOther = y + getAscent(graphics, subFont, "----") - 1;
                g2.drawString(Integer.toString(count), iX, yForOther);
                g2.drawString(pti.Schedule, scheduleStart, yForOther);
                g2.drawString(pti.DrugMealRelationship, relationStart, yForOther);
                g2.drawString(pti.Days, daysStart, yForOther);

                AttributedString attributedString = new AttributedString(pti.DrugName);
                attributedString.addAttribute(TextAttribute.FONT, subFont);
                AttributedCharacterIterator paragraph = attributedString.getIterator();
                int paragraphStart = paragraph.getBeginIndex();
                int paragraphEnd = paragraph.getEndIndex();
                LineBreakMeasurer lineMeasurer = new LineBreakMeasurer(paragraph, new FontRenderContext(null, false, false));

                float breakWidth = drugNameMaxWidth;
                lineMeasurer.setPosition(paragraphStart);
                while (lineMeasurer.getPosition() < paragraphEnd) {
                    TextLayout layout;
                    layout = lineMeasurer.nextLayout(breakWidth);
                    float drawPosX = iX + 15;
                    y += layout.getAscent();
                    layout.draw(g2, drawPosX, y);
                    y += layout.getDescent() + layout.getLeading();
                }     
                count++;
            }
        }
        
        //other requerenment
        if (otherRequ != null) {
            if (otherRequ.toArray().length > 0) {
                y += 15;
                
                g2.drawString("Other Requirements", iX, y);
                y += GetStringDimention(graphics, subFont, "Other Requirements").height;
                
                int ct = 1;
                for (String otr : otherRequ) {
                    g2.drawString(Integer.toString(ct), iX, y);
                    g2.drawString(otr, iX + 15, y);
                    y += GetStringDimention(graphics, subFont, otr).height;
                    ct++;
                }
            }
        }
       
        if (!specialNote.equals("")) {
            AttributedString attributedString = new AttributedString("NOTE : " + specialNote);
            attributedString.addAttribute(TextAttribute.FONT, subFont);
            AttributedCharacterIterator paragraph = attributedString.getIterator();
            int paragraphStart = paragraph.getBeginIndex();
            int paragraphEnd = paragraph.getEndIndex();
            LineBreakMeasurer lineMeasurer = new LineBreakMeasurer(paragraph, new FontRenderContext(null, false, false));

            float breakWidth = iWidth;
            lineMeasurer.setPosition(paragraphStart);
            while (lineMeasurer.getPosition() < paragraphEnd) {
            TextLayout layout;
            layout = lineMeasurer.nextLayout(breakWidth);
            float drawPosX = iX;
            y += layout.getAscent();
            layout.draw(g2, drawPosX, y);
            y += layout.getDescent() + layout.getLeading();
        }
        }
        
        g2.drawString("  Signature  ", (iX + iWidth) - GetStringDimention(graphics, subFont, "  Signature  ").width - 1, (iY + (iHeight / 2)) - 10);
        g2.drawString("------------------", (iX + iWidth) - GetStringDimention(graphics, subFont, "  Signature  ").width - 10, (iY + (iHeight / 2)) - 18);
        // </editor-fold>
       
        // <editor-fold defaultstate="collapsed" desc="Patient Part">
        y = iY + (iHeight / 2);
        
        //draw logo
        g2.drawImage(pic, iX, y + 10, 40, 40, null);
        
        //draw medical center name
        y += GetStringDimention(graphics, titleFont, medicalCenterName).height;
        g2.setFont(titleFont);
        g2.drawString(medicalCenterName, iX + 55, y);
        
        
        //draw doctor id + name
        y += GetStringDimention(graphics, subFont, docRegID).height;
        g2.setFont(subFont);
        g2.drawString(docRegID + " | " + docName, iX + 55, y);
        

        //draw phone image and phone number
        y += GetStringDimention(graphics, subFont, docPhone).height;
        g2.drawImage(phonePic, iX + 55, y - 8, 10, 10, null);
        g2.drawString(docPhone, iX + 55 + 12, y);
        
        //draw email image and email
        g2.drawImage(emailPic, iX + 55 + 12 + GetStringDimention(graphics, subFont, docPhone).width + 5, y - 8, 10, 10, null);
        g2.drawString(docEmail, iX + 55 + 12 + GetStringDimention(graphics, subFont, docPhone).width + 5 + 12, y);
        
        //draw ref
        g2.drawString(RefNo, (iX + iWidth) - GetStringDimention(graphics, subFont, RefNo).width, iY + (iHeight / 2) + oneLineHeight);
        
        //draw date time
        g2.drawString(date + "  " +  time, (iX + iWidth) - GetStringDimention(graphics, subFont, date + "  " +  time).width, iY + (iHeight / 2) + (oneLineHeight * 2));
        
        //draw patient details
        g2.drawString(patientID + "  " + patientName, (iX + iWidth) - GetStringDimention(graphics, subFont, patientID + "  " + patientName).width, iY + (iHeight / 2) + (oneLineHeight * 3));
        
        //draw headers
        y += 30;
        
        g2.drawString("Drug Name", drugNameStart, y);
        g2.drawString("Schedule", scheduleStart, y);
        g2.drawString("D/M Rlt", relationStart, y);
        g2.drawString("Days", daysStart, y);
        
        //draw header line
        y += GetStringDimention(graphics, subFont, "Drug Name").height;
        g2.drawString("----------------------------------------------------------------------------------------------------------------------", iX, y);
         
        //draw prescription items
       
        if (presItems != null) {
            int count = 1;
            for (PrescriptionItem pti : presItems) {

                int yForOther = y + getAscent(graphics, subFont, "----") - 1;
                g2.drawString(Integer.toString(count), iX, yForOther);
                g2.drawString(pti.Schedule, scheduleStart, yForOther);
                g2.drawString(pti.DrugMealRelationship, relationStart, yForOther);
                g2.drawString(pti.Days, daysStart, yForOther);

                AttributedString attributedString = new AttributedString(pti.DrugName);
                attributedString.addAttribute(TextAttribute.FONT, subFont);
                AttributedCharacterIterator paragraph = attributedString.getIterator();
                int paragraphStart = paragraph.getBeginIndex();
                int paragraphEnd = paragraph.getEndIndex();
                LineBreakMeasurer lineMeasurer = new LineBreakMeasurer(paragraph, new FontRenderContext(null, false, false));

                float breakWidth = drugNameMaxWidth;
                lineMeasurer.setPosition(paragraphStart);
                while (lineMeasurer.getPosition() < paragraphEnd) {
                    TextLayout layout;
                    layout = lineMeasurer.nextLayout(breakWidth);
                    float drawPosX = iX + 15;
                    y += layout.getAscent();
                    layout.draw(g2, drawPosX, y);
                    y += layout.getDescent() + layout.getLeading();
                }     
                count++;
            }
        }
        
        //other requerenment
        if (otherRequ != null) {
            if (otherRequ.toArray().length > 0) {
                y += 15;
                
                g2.drawString("Other Requirements", iX, y);
                y += GetStringDimention(graphics, subFont, "Other Requirements").height;
                
                int ct = 1;
                for (String otr : otherRequ) {
                    g2.drawString(Integer.toString(ct), iX, y);
                    g2.drawString(otr, iX + 15, y);
                    y += GetStringDimention(graphics, subFont, otr).height;
                    ct++;
                }
            }
        }
       
        if (!specialNote.equals("")) {
            AttributedString attributedString = new AttributedString("NOTE : " + specialNote);
            attributedString.addAttribute(TextAttribute.FONT, subFont);
            AttributedCharacterIterator paragraph = attributedString.getIterator();
            int paragraphStart = paragraph.getBeginIndex();
            int paragraphEnd = paragraph.getEndIndex();
            LineBreakMeasurer lineMeasurer = new LineBreakMeasurer(paragraph, new FontRenderContext(null, false, false));

            float breakWidth = iWidth;
            lineMeasurer.setPosition(paragraphStart);
            while (lineMeasurer.getPosition() < paragraphEnd) {
            TextLayout layout;
            layout = lineMeasurer.nextLayout(breakWidth);
            float drawPosX = iX;
            y += layout.getAscent();
            layout.draw(g2, drawPosX, y);
            y += layout.getDescent() + layout.getLeading();
        }
        }
        
        g2.drawString("  Signature  ", (iX + iWidth) - GetStringDimention(graphics, subFont, "  Signature  ").width - 1, iY + iHeight - 10);
        g2.drawString("------------------", (iX + iWidth) - GetStringDimention(graphics, subFont, "  Signature  ").width - 10, iY + iHeight - 18);
        // </editor-fold>
        
        
        
        
        
        
        
        g2.dispose();
        return Printable.PAGE_EXISTS;
    }
    
    private Dimension GetStringDimention(Graphics g, Font font, String text){
        FontMetrics metrics = g.getFontMetrics(font);
        return new Dimension(metrics.stringWidth(text), metrics.getHeight());
    }
    
    private void drawCenteredString(Graphics g, String text, Rectangle rect, Font font) {
        FontMetrics metrics = g.getFontMetrics(font);
        int x = rect.x + (rect.width - metrics.stringWidth(text)) / 2;
        int y = rect.y + ((rect.height - metrics.getHeight()) / 2) + metrics.getAscent();
        g.setFont(font);
        g.drawString(text, x, y);
    }
    
    private int getAscent(Graphics g, Font font, String text) {
        FontMetrics metrics = g.getFontMetrics(font);
        return metrics.getAscent();
    }
}
