/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage.Mbox;

import MainPackage.Enum.DialogResult;
import MainPackage.Enum.MBoxButton;
import MainPackage.Enum.MBoxIcon;

/**
 *
 * @author Nayanajith
 */
public class MessageBox {
    public static DialogResult Show(java.awt.Frame parent, String msg, String title, MBoxButton button, MBoxIcon icon){
        MBox msgBox = new MBox(parent, true, "<html>" + msg, title, button, icon);
        msgBox.setVisible(true);
        
        MBoxButton btn = msgBox.ClickedButton;
        msgBox.dispose();
           
        if (btn == MBoxButton.OK) {
            return DialogResult.OK;   
        }
        else if (btn == MBoxButton.Yes) {
            return DialogResult.Yes;
        }
        else if (btn == MBoxButton.No) {
            return DialogResult.No;
        }
        else{
            return DialogResult.Cancel;
        }
    }
   
    public static DialogResult Show(java.awt.Frame parent, String msg){
        MBox msgBox = new MBox(parent, true, "<html>" + msg, "", MBoxButton.OK, MBoxIcon.Information);
        msgBox.setVisible(true);
        
        MBoxButton btn = msgBox.ClickedButton;
        msgBox.dispose();
           
        if (btn == MBoxButton.OK) {
            return DialogResult.OK;   
        }
        else if (btn == MBoxButton.Yes) {
            return DialogResult.Yes;
        }
        else if (btn == MBoxButton.No) {
            return DialogResult.No;
        }
        else{
            return DialogResult.Cancel;
        }
    }
}
