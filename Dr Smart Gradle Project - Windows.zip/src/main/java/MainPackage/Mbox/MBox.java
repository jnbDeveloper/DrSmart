/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage.Mbox;

import MainPackage.Enum.MBoxButton;
import MainPackage.Enum.MBoxIcon;
import MainPackage.CreatedComponents.RoundedLabel;
import MainPackage.CreatedComponents.RoundedPanel;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.geom.RoundRectangle2D;

/**
 *
 * @author Nayanajith
 */
public class MBox extends javax.swing.JDialog {

    public MBoxButton ClickedButton;
    
    static String Message;
    static String Title;
    static MBoxButton Button;
    static MBoxIcon Icon;
    
    private int mouseX, mouseY;
    
    /**
     * Creates new form MBox
     */
    public MBox(java.awt.Frame parent, boolean modal, String msg, String title, MBoxButton button, MBoxIcon icon) {
        super(parent, modal);
        initComponents();
        
        //setBackground(new Color(0, 0, 0, 0));
        //getRootPane().setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(150, 150, 150)));
        
        Message = msg;
        Title = title;
        Button = button;
        Icon = icon;
        
        AddButtons();
        AddIcon();
        
        lblTitle.setText(Title);
        lblMessage.setText(Message);
    }
    
    public void AddIcon(){
        if (Icon == MBoxIcon.Information) {
            lblIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Information.png")));
        }
        else if (Icon == MBoxIcon.Question) {
            lblIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Question.png")));
        }
        else if (Icon == MBoxIcon.Warning) {
            lblIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Warning.png")));
        }
        else{
            lblIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Error.png")));
        }
    }
    
    public  void AddButtons(){
        if (Button == MBoxButton.OK) {  
            JLabel okButton = new JLabel("OK");
            okButton.setName("btnOK");
            okButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
            okButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/OK.png")));
            okButton.setBounds(pnlMain.getWidth() - 110, pnlMain.getHeight() - 40, 100, 30);
            okButton.setHorizontalAlignment(JLabel.CENTER);
            okButton.setBorder(BorderFactory.createEtchedBorder());
            okButton.addMouseListener(new MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    OKButton_Clicked();
                }
            });      
            pnlMain.add(okButton);
            pnlMain.validate();
            pnlMain.repaint();
        }
        else if (Button == MBoxButton.YesNo) {
            JLabel yesButton = new JLabel("Yes");
            yesButton.setName("btnYes");
            yesButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
            yesButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/OK.png")));
            yesButton.setBounds(pnlMain.getWidth() - 110, pnlMain.getHeight() - 40, 100, 30);
            yesButton.setHorizontalAlignment(JLabel.CENTER);
            yesButton.setBorder(BorderFactory.createEtchedBorder());
            yesButton.addMouseListener(new MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    YesButton_Clicked();
                }
            });          
            
            JLabel noButton = new JLabel("No");
            noButton.setName("btnNo");
            noButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
            noButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Cancel.png")));
            noButton.setBounds(pnlMain.getWidth() - 220, pnlMain.getHeight() - 40, 100, 30);
            noButton.setHorizontalAlignment(JLabel.CENTER);
            noButton.setBorder(BorderFactory.createEtchedBorder());
            noButton.addMouseListener(new MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    NoButton_Clicked();
                }
            });      
            pnlMain.add(yesButton);
            pnlMain.add(noButton);
            pnlMain.validate();
            pnlMain.repaint();
        }
        else {
            JLabel okButton = new JLabel("OK");
            okButton.setName("btnOK");
            okButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
            okButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/OK.png")));
            okButton.setBounds(pnlMain.getWidth() - 110, pnlMain.getHeight() - 40, 100, 30);
            okButton.setHorizontalAlignment(JLabel.CENTER);
            okButton.setBorder(BorderFactory.createEtchedBorder());
            okButton.addMouseListener(new MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    OKButton_Clicked();
                }
            });          
            
            JLabel cancelButton = new JLabel("Cancel");
            cancelButton.setName("btnCancel");
            cancelButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
            cancelButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Cancel.png")));
            cancelButton.setBounds(pnlMain.getWidth() - 220, pnlMain.getHeight() - 40, 100, 30);
            cancelButton.setHorizontalAlignment(JLabel.CENTER);
            cancelButton.setBorder(BorderFactory.createEtchedBorder());
            cancelButton.addMouseListener(new MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    CancelButton_Clicked();
                }
            });      
            pnlMain.add(okButton);
            pnlMain.add(cancelButton);
            pnlMain.validate();
            pnlMain.repaint();
        }
    }
    
    public void OKButton_Clicked(){
        ClickedButton = MBoxButton.OK;
        this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
    
    public void YesButton_Clicked(){
        ClickedButton = MBoxButton.Yes;
        this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
    
    public void NoButton_Clicked(){
        ClickedButton = MBoxButton.No;
        this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
    
    public void CancelButton_Clicked(){
        ClickedButton = MBoxButton.Cancel;
        this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMain = new javax.swing.JPanel();
        pnlTop = new javax.swing.JPanel();
        lblClose = new javax.swing.JLabel();
        lblTitle = new javax.swing.JLabel();
        lblIcon = new javax.swing.JLabel();
        lblMessage = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        setResizable(false);
        setSize(new java.awt.Dimension(396, 216));

        pnlMain.setBackground(new java.awt.Color(255, 255, 255));
        pnlMain.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pnlMain.setForeground(new java.awt.Color(51, 255, 51));
        pnlMain.setLayout(null);

        pnlTop.setBackground(new java.awt.Color(1, 109, 156));
        pnlTop.setPreferredSize(new java.awt.Dimension(396, 32));
        pnlTop.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                pnlTopMouseDragged(evt);
            }
        });
        pnlTop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pnlTopMousePressed(evt);
            }
        });

        lblClose.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblClose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CloseWhiteSmall.png"))); // NOI18N
        lblClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblClose.setPreferredSize(new java.awt.Dimension(32, 32));
        lblClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCloseMouseClicked(evt);
            }
        });

        lblTitle.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout pnlTopLayout = new javax.swing.GroupLayout(pnlTop);
        pnlTop.setLayout(pnlTopLayout);
        pnlTopLayout.setHorizontalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTopLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 149, Short.MAX_VALUE)
                .addComponent(lblClose, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2))
        );
        pnlTopLayout.setVerticalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblClose, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pnlMain.add(pnlTop);
        pnlTop.setBounds(0, 0, 396, 32);
        pnlMain.add(lblIcon);
        lblIcon.setBounds(20, 50, 35, 35);

        lblMessage.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblMessage.setToolTipText("");
        lblMessage.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblMessage.setAutoscrolls(true);
        pnlMain.add(lblMessage);
        lblMessage.setBounds(60, 58, 310, 60);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, 396, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCloseMouseClicked
        ClickedButton = MBoxButton.Cancel;
        this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_lblCloseMouseClicked

    private void pnlTopMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlTopMouseDragged
        this.setLocation(this.getX() + evt.getX() - mouseX, this.getY() + evt.getY() - mouseY);
    }//GEN-LAST:event_pnlTopMouseDragged

    private void pnlTopMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlTopMousePressed
        mouseX = evt.getX();
        mouseY = evt.getY();
    }//GEN-LAST:event_pnlTopMousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MBox.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MBox.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MBox.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MBox.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                MBox dialog = new MBox(new javax.swing.JFrame(), true, Message, Title, Button, Icon);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblClose;
    private javax.swing.JLabel lblIcon;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JPanel pnlTop;
    // End of variables declaration//GEN-END:variables
}
