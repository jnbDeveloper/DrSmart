/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage.CreatedComponents;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Area;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Nayanajith
 */
public class RoundedLabel extends JLabel
{
    private Color backgroundColor;
    private int cornerRadius = 15;
    private boolean drawBorder;

    public RoundedLabel(int radius, boolean drawborder) {
        super();
        cornerRadius = radius;
        drawBorder = drawborder;
    }

    public RoundedLabel(int radius, Color bgColor, boolean drawborder) {
        super();
        cornerRadius = radius;
        backgroundColor = bgColor;
        drawBorder = drawborder;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Dimension arcs = new Dimension(cornerRadius, cornerRadius);
        int width = getWidth();
        int height = getHeight();
        Font font = getFont();
        String text = getText();
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        
        /*Area fullArea = new Area(new Rectangle(0, 0, width, height));
        RoundRectangle2D.Double rect = new RoundRectangle2D.Double(0, 0, width, height, arcs.width, arcs.height);
        
        fullArea.subtract(new Area(rect));
        graphics.setColor(new Color(0, 0, 0, 0));
        graphics.setComposite(AlphaComposite.Dst);
        graphics.fill(fullArea);*/
        
        
        
        
        
        //Draws the rounded panel with borders.
        if (backgroundColor != null) {
            graphics.setColor(backgroundColor);
        } else {
            graphics.setColor(getBackground());
        }
        graphics.fillRoundRect(0, 0, width, height, arcs.width, arcs.height); //paint background
        graphics.setColor(getForeground());
        
        if (drawBorder){
            graphics.drawRoundRect(0, 0, width, height, arcs.width, arcs.height); //paint border
        }
        
        //int textWidth = g.getFontMetrics().stringWidth(text);
        //int textHeigth = g.getFontMetrics(font).getHeight();
        
        //graphics.setFont(font);
        //graphics.drawString(text, (width - textWidth) / 2, (height - textHeigth) / 2);
        
        //JOptionPane.showMessageDialog(this, String.valueOf(textHeigth),"Alert",JOptionPane.WARNING_MESSAGE);
        
        drawCenteredString(graphics, text, new Rectangle(0, 0, width, height), font);
    }
      
    private void drawCenteredString(Graphics g, String text, Rectangle rect, Font font) {
        FontMetrics metrics = g.getFontMetrics(font);
        int x = rect.x + (rect.width - metrics.stringWidth(text)) / 2;
        int y = rect.y + ((rect.height - metrics.getHeight()) / 2) + metrics.getAscent();
        g.setFont(font);
        g.drawString(text, x, y);
    }
}
