/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage.CreatedComponents;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Area;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Nayanajith
 */
public class RoundedLabelOuterOpacity extends JLabel
{
    private Color backgroundColor;
    private int cornerRadius = 15;
    private boolean drawBorder;

    public RoundedLabelOuterOpacity(int radius, boolean drawborder) {
        super();
        cornerRadius = radius;
        drawBorder = drawborder;
    }

    public RoundedLabelOuterOpacity(int radius, Color bgColor, boolean drawborder) {
        super();
        cornerRadius = radius;
        backgroundColor = bgColor;
        drawBorder = drawborder;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Dimension arcs = new Dimension(cornerRadius, cornerRadius);
        int width = getWidth();
        int height = getHeight();
        Font font = getFont();
        String text = getText();
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        
        Area fullArea = new Area(new Rectangle(0, 0, width, height));
        RoundRectangle2D.Double rect = new RoundRectangle2D.Double(0, 0, width, height, arcs.width, arcs.height);
        
        fullArea.subtract(new Area(rect));
        graphics.setColor(new Color(0, 0, 0, 0));
        graphics.setComposite(AlphaComposite.Clear);
        graphics.fill(fullArea);
        
        if (drawBorder){
            graphics.drawRoundRect(0, 0, width, height, arcs.width, arcs.height); //paint border
        }
    }
}
