/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage.CreatedComponents;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Nayanajith
 */
public class StripedRowTableCellRenderer extends DefaultTableCellRenderer {
    private static final Color WHITE = new Color(252, 252, 252);
    private static final Color LIGHTGRAY = new Color(240, 240, 240);
 
    private final JCheckBox ckb = new JCheckBox();

    public StripedRowTableCellRenderer() {
      setOpaque(true); //MUST do this for background to show up.
    }
    
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
      JComponent c = (JComponent)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

      if (!isSelected)
      {
        if (row % 2 == 0)
        {
          c.setBackground(LIGHTGRAY);
        }
        else
        {
          c.setBackground(WHITE);
        }
      }

      if (value instanceof Boolean) { // Boolean
        ckb.setSelected(((Boolean) value));
        ckb.setHorizontalAlignment(JLabel.CENTER);
        ckb.setBackground(super.getBackground());
        if (isSelected || hasFocus) {
            ckb.setBackground(table.getSelectionBackground());
        }
        return ckb;
      }
      
      setBorder(BorderFactory.createEmptyBorder(0, 7, 0, 0));
      setFont(new Font("Roboto", Font.PLAIN, 13));
      
      return c;
    }
}
