/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPackage.CreatedComponents;

import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 *
 * @author Nayanajith
 */
public class RoundedPanelOuterOpacity extends JPanel
{
    private Color backgroundColor;
    private int cornerRadius = 15;
    private boolean drawBorder;

    public RoundedPanelOuterOpacity(LayoutManager layout, int radius, boolean drawborder) {
        super(layout);
        cornerRadius = radius;
        drawBorder = drawborder;
    }

    public RoundedPanelOuterOpacity(LayoutManager layout, int radius, Color bgColor, boolean drawborder) {
        super(layout);
        cornerRadius = radius;
        backgroundColor = bgColor;
        drawBorder = drawborder;
    }

    public RoundedPanelOuterOpacity(int radius, boolean drawborder) {
        super();
        cornerRadius = radius;
        drawBorder = drawborder;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Dimension arcs = new Dimension(cornerRadius, cornerRadius);
        int width = getWidth();
        int height = getHeight();
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        
        
        Area fullArea = new Area(new Rectangle(0, 0, width, height));
        RoundRectangle2D.Double rect = new RoundRectangle2D.Double(0, 0, width, height, arcs.width, arcs.height);
        
        fullArea.subtract(new Area(rect));
        graphics.setColor(new Color(0, 0, 0, 0));
        graphics.setComposite(AlphaComposite.Clear);
        graphics.fill(fullArea);
        
        
        
        /*graphics.setColor(getBackground());
        

        graphics.fillRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height); //paint background
        graphics.setColor(getForeground());*/
        
        if (drawBorder){
            graphics.drawRoundRect(0, 0, width, height, arcs.width, arcs.height); //paint border
        }
    }
}