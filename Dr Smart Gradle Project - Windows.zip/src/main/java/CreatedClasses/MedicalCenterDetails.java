/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CreatedClasses;


import javax.swing.ImageIcon;
/**
 *
 * @author Nayanajith
 */
public class MedicalCenterDetails {
    public String Email;
    public String Password;
    public String MedicalCenterName;
    public ImageIcon MedicalCenterLogo;
    public String PhoneNumber;
    public String Address;
    public String Currency;
    public String GST;
    public String APIKey;
    public String APISecret;
}
