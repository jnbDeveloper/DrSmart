/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CreatedClasses;

/**
 *
 * @author Nayanajith
 */
public class AppointmentDetails {
    public int AppointmentID; 
    public String PatientName;
    public String DoctorName;
    public String AppointmentDate;
    public String ApointmentTime;
    public String PatientEmail;
    public String PhoneNumber;
}
