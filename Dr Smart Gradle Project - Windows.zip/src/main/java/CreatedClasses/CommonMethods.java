/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CreatedClasses;

import MainPackage.Enum.MBoxButton;
import MainPackage.Enum.MBoxIcon;
import MainPackage.MainForm;
import MainPackage.Mbox.MessageBox;
import MainPackage.SameNamePatient;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Area;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Nayanajith
 */
public class CommonMethods {
    
    static ImageIcon  img;
    static String currentDir = "jdbc:sqlite:" + DBPath();
    static Connection con = null;
    
    public CommonMethods(){
        img = new ImageIcon(getClass().getResource("/Information.png"));
    }   

    public static ImageIcon GetPicByUsername(String username){ 
        Statement statement = null;
        byte[] pic = null;

        try{ 
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();
            ResultSet result = statement.executeQuery(String.format("SELECT photo FROM doctors WHERE username = '%s'", username));
            result.next();
            pic = result.getBytes(1);

            ImageIcon imageIcon = new ImageIcon(pic);

            return imageIcon;

        }catch (Exception ex) {
            return img;
        }
        finally{
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static javax.swing.ImageIcon makeRoundedCorner(Image image, int w, int h, int cornerRadius) {
        
        BufferedImage output = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = output.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g2.setComposite(AlphaComposite.SrcOver);
        g2.drawImage(image, 0, 0, w, h, null);
        
        g2.setColor(new Color(0, 0, 0, 0));
        g2.setComposite(AlphaComposite.DstIn);
        
        Area fullArea = new Area(new Rectangle(0, 0, w, h));
        RoundRectangle2D.Double rect = new RoundRectangle2D.Double(0, 0, w, h, cornerRadius, cornerRadius);
        fullArea.subtract(new Area(rect));
        
        g2.fill(fullArea);
        
        g2.dispose();

        ImageIcon newIcon = new ImageIcon(output);
        
        return newIcon;
    }
    
    public static boolean AlreadyAdded( String table, String column, String key){  
        Statement statement = null;
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();
            ResultSet result = statement.executeQuery(String.format("SELECT %s FROM %s WHERE %s = '%s'", column, table, column, key));
            if (result.next() == false) {
                return false;
            }
            else{
                return true;
            }
        } catch (Exception e) {
            return true;
        }
        finally{
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static boolean AlreadyUsedOthers(String table, String column, String key, String uniqueColumn, String uniqueKey){  
        Statement statement = null;
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();
            ResultSet result = statement.executeQuery(String.format("SELECT %s FROM %s WHERE %s != '%s' AND %s = '%s'", column, table, uniqueColumn, uniqueKey, column, key));
            if (result.next() == false) {
                return false;
            }
            else{
                return true;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return true;
        }
        finally{
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static String GetNameByUsername(String username){ 
        Statement statement = null;

        try{ 
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();
            ResultSet result = statement.executeQuery(String.format("SELECT doctor_name FROM doctors WHERE username = '%s'", username));
            result.next();

            return result.getString(1);

        }catch (Exception ex) {
            return null;
        }
        finally{
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static List<Patient> GetPatientByID(String patientID) {
        Statement statement = null;
        
        List<Patient> patients = new ArrayList<Patient>();
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();

            ResultSet result = statement.executeQuery(String.format("SELECT pp.*, pd.age, pd.weight, pd.height, pd.blood_group, pd.blood_presure, pd.family_history, pd.previous_dignose, pd.blood_report, pd.gender FROM patients pp LEFT JOIN patients_details pd ON pp.patient_id = pd.patient_id WHERE pp.patient_id = '%s'", patientID));

            
            while (result.next()) {
                Patient pt = new Patient();
                pt.PatientID = result.getString(1);
                pt.PatientName = result.getString(2);
                pt.PhoneNumber = result.getString(3);
                pt.Birthday = result.getString(4);
                pt.Email = result.getString(5);
                pt.PostalCode = result.getString(6);
                pt.Address = result.getString(7);
                pt.Provider = result.getString(8);
                pt.GuardianName = result.getString(9);
                pt.GuardianPhone = result.getString(10);
                pt.AgeGroup = result.getString(11);
                pt.GotVaccine = result.getString(12);
                pt.VaccineName = result.getString(13);
                pt.InjectedDate = result.getString(14);
            
                pt.Age = result.getString(15);
                pt.Weight = result.getString(16);
                pt.Height = result.getString(17);
                pt.BloodGroup = result.getString(18);
                pt.BloodPresure = result.getString(19);
                pt.FamilyHistory = result.getString(20);
                pt.PreviousDignose = result.getString(21);
                pt.BloodReport = result.getString(22);
                pt.Gender = result.getString(23);
                
                patients.add(pt);
            }
            
            return patients;

        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static List<Patient> GetPatientByName(String patientName) {
        Statement statement = null;
        
        List<Patient> patients = new ArrayList<Patient>();
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();

            ResultSet result = statement.executeQuery(String.format("SELECT pp.*, pd.age, pd.weight, pd.height, pd.blood_group, pd.blood_presure, pd.family_history, pd.previous_dignose, pd.blood_report, pd.gender FROM patients pp LEFT JOIN patients_details pd ON pp.patient_id = pd.patient_id WHERE pp.patient_name LIKE '%s'", patientName + "%"));

            
            while (result.next()) {
                Patient pt = new Patient();
                pt.PatientID = result.getString(1);
                pt.PatientName = result.getString(2);
                pt.PhoneNumber = result.getString(3);
                pt.Birthday = result.getString(4);
                pt.Email = result.getString(5);
                pt.PostalCode = result.getString(6);
                pt.Address = result.getString(7);
                pt.Provider = result.getString(8);
                pt.GuardianName = result.getString(9);
                pt.GuardianPhone = result.getString(10);
                pt.AgeGroup = result.getString(11);
                pt.GotVaccine = result.getString(12);
                pt.VaccineName = result.getString(13);
                pt.InjectedDate = result.getString(14);
            
                pt.Age = result.getString(15);
                pt.Weight = result.getString(16);
                pt.Height = result.getString(17);
                pt.BloodGroup = result.getString(18);
                pt.BloodPresure = result.getString(19);
                pt.FamilyHistory = result.getString(20);
                pt.PreviousDignose = result.getString(21);
                pt.BloodReport = result.getString(22);
                pt.Gender = result.getString(23);
                
                patients.add(pt);
            }
            
            return patients;

        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static Doctor CurrentLoggedInDoctor(){
        Statement statement = null;
       
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();

            ResultSet result = statement.executeQuery(String.format("SELECT dt.doctor_id, dt.doctor_name, dt.phone_number, dt.email, dt.doctor_fee FROM loggedin_user lu LEFT JOIN doctors dt ON lu.username = dt.username"));

            result.next();
            
            return new Doctor(result.getString(1), result.getString(2), result.getString(3), result.getString(4), result.getString(5));
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static MedicalCenterDetails GetMedicalCenterDetails(){ 
        Statement statement = null;
        byte[] pic = null;

        try{ 
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();
            ResultSet result = statement.executeQuery(String.format("SELECT * FROM medical_center_details WHERE id = 1"));
            result.next();
            
            MedicalCenterDetails mcd = new MedicalCenterDetails();
            mcd.Email = result.getString(2);
            mcd.Password = result.getString(3);
            mcd.MedicalCenterName = result.getString(4);
            mcd.PhoneNumber = result.getString(6);
            mcd.Address = result.getString(7);      
            mcd.Currency = result.getString(8);
            mcd.GST = result.getString(9);
            mcd.APIKey = result.getString(10);
            mcd.APISecret = result.getString(11);
            
            pic = result.getBytes(5);
            ImageIcon imageIcon = new ImageIcon(pic);

            mcd.MedicalCenterLogo = imageIcon;
            
            return mcd;

        }catch (Exception ex) {
            return null;
        }
        finally{
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static Doctor GetDoctorByID(String docID){
        Statement statement = null;
        
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();

            ResultSet result = statement.executeQuery(String.format("SELECT * FROM doctors WHERE doctor_id = '%s'", docID));
            result.next();
            
            return new Doctor(result.getString(1), result.getString(2), result.getString(3), result.getString(5), result.getString(8));
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static boolean SendEmail(String toEmail, String subject, String msg) {
        MedicalCenterDetails mcd = GetMedicalCenterDetails();
        
        String mail = mcd.Email;
        String pass = mcd.Password;
        
        if (mail.equals("") || pass.equals("")) {
            return false;
        }
        
        Properties properties = new Properties();

        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(mail, pass);
            }
        });
        Message message = prepareMessage(session, mail, toEmail, subject, msg);

        try {
            Transport.send(message);
            System.out.println("Email send successful.");
            return true;
        } catch (MessagingException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }
    
    private static Message prepareMessage(Session session, String myUsername, String toEmail, String subject, String msg) {
        Message message = new MimeMessage(session);
        try {
            message.setFrom(new InternetAddress(myUsername));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
            message.setSubject(subject);
            message.setText(msg);
            return message;
        } catch (Exception ex) {
        }
        return null;
    }
    
    public static boolean EmailNotifiIsOn(){
        Statement statement = null;
        
        try {
            con = DriverManager.getConnection(currentDir);
            
            statement = con.createStatement();

            ResultSet result = statement.executeQuery(String.format("SELECT * FROM email_notifi_system"));
            result.next();
            
            String status = result.getString(1);
            
            if (status.equals("yes")) {
                return true;
            }
            else {
                return false;
            }
        } catch (Exception ex) {
            return false;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static boolean SMSNotifiIsOn(){
        Statement statement = null;
        
        try {
            con = DriverManager.getConnection(currentDir);
            
            statement = con.createStatement();

            ResultSet result = statement.executeQuery(String.format("SELECT * FROM sms_notifi_system"));
            result.next();
            
            String status = result.getString(1);
            
            if (status.equals("yes")) {
                return true;
            }
            else {
                return false;
            }
        } catch (Exception ex) {
            return false;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static List<AppointmentDetails> GetTodayAppointments(){
        Statement statement = null;
       
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
        String date = dtf.format(LocalDateTime.now());
        
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();

            //ResultSet result = statement.executeQuery(String.format("SELECT pt.patient_name, dt.doctor_name, app.date, app.time, pt.email, app.id, pt.phone_number  FROM appointments app LEFT JOIN patients pt ON app.patient_id = pt.patient_id LEFT JOIN doctors dt ON app.doctor_id = dt.doctor_id WHERE date = '%s' AND is_checked = 'No' AND send_reminder = 'No'", date));
            ResultSet result = statement.executeQuery(String.format("SELECT pt.patient_name, dt.doctor_name, app.date, app.time, pt.email, app.id, CASE WHEN pt.age_group = 'Adult' THEN pt.phone_number WHEN pt.age_group = 'Child' THEN pt.guardian_phone ELSE '' END AS phone_number FROM appointments app LEFT JOIN patients pt ON app.patient_id = pt.patient_id LEFT JOIN doctors dt ON app.doctor_id = dt.doctor_id WHERE date = '%s' AND is_checked = 'No' AND send_reminder = 'No'", date));

            List<AppointmentDetails> adl = new ArrayList<AppointmentDetails>();
            while (result.next()) {
                AppointmentDetails ad = new AppointmentDetails();
                ad.PatientName = result.getString(1);
                ad.DoctorName = result.getString(2);
                ad.AppointmentDate = result.getString(3);
                ad.ApointmentTime = result.getString(4);
                ad.PatientEmail = result.getString(5);
                ad.AppointmentID = result.getInt(6);
                ad.PhoneNumber = result.getString(7);
                
                adl.add(ad);
            }
            
            return adl;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static void AddNotification(String notifi){
        PreparedStatement pStatement = null;
        try {
            con = DriverManager.getConnection(currentDir);

            pStatement = con.prepareStatement("INSERT INTO notifications VALUES(?)");
            pStatement.setString(1, notifi);

            pStatement.execute();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            try {
                con.close();
                pStatement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static String DBPath () {
        /*try {
            // Get path of the JAR file
            String jarPath = MainForm.class
                    .getProtectionDomain()
                    .getCodeSource()
                    .getLocation()
                    .toURI()
                    .getPath();
            String jarName = jarPath.substring(jarPath.lastIndexOf("/") + 1);
            
            String dbPath = "";
            
            if (jarName.equals("") || jarName == null) {
                //dbPath = (jarPath + "Database.db").substring(1);
                dbPath = (jarPath + "Database.db");
                return dbPath;
            }
            else {
                //dbPath = jarPath.replace(jarName, "Database.db").substring(1);
                dbPath = jarPath.replace(jarName, "Database.db");
                return dbPath;
            }
        } catch (URISyntaxException e) {
            return "";
        }*/
        
        return System.getProperty("user.dir") + "\\Database.db";
    }
    
    public static String GetExecutePath() {
        return System.getProperty("user.dir") + "\\";
    }
    
    public static String ActivateDBPath () {
        /*try {
            // Get path of the JAR file
            String jarPath = MainForm.class
                    .getProtectionDomain()
                    .getCodeSource()
                    .getLocation()
                    .toURI()
                    .getPath();
            String jarName = jarPath.substring(jarPath.lastIndexOf("/") + 1);
            
            String dbPath = "";
            
            if (jarName.equals("") || jarName == null) {
                //dbPath = (jarPath + "Database.db").substring(1);
                dbPath = (jarPath + "DsmrtActivate.db");
                return dbPath;
            }
            else {
                //dbPath = jarPath.replace(jarName, "Database.db").substring(1);
                dbPath = jarPath.replace(jarName, "DsmrtActivate.db");
                return dbPath;
            }
        } catch (URISyntaxException e) {
            return "";
        }*/
        
        return System.getProperty("user.dir") + "\\DsmrtActivate.db";
    }
    
    public static String BloodReportPath () {
        try {
            // Get path of the JAR file
            String jarPath = MainForm.class
                    .getProtectionDomain()
                    .getCodeSource()
                    .getLocation()
                    .toURI()
                    .getPath();
            String jarName = jarPath.substring(jarPath.lastIndexOf("/") + 1);
            
            String dbPath = "";
            
            if (jarName.equals("") || jarName == null) {
                //dbPath = (jarPath + "BloodReports").substring(1);
                dbPath = (jarPath + "BloodReports");
                return dbPath;
            }
            else {
                //dbPath = jarPath.replace(jarName, "BloodReports").substring(1);
                dbPath = jarPath.replace(jarName, "BloodReports");
                return dbPath;
            }
        } catch (URISyntaxException e) {
            return "";
        }
    }
    
    public static List<String> GetMedicalTests(){
        Statement statement = null;
        
        List<String> medicalTests = new ArrayList<String>();
        try {
            con = DriverManager.getConnection(currentDir);
            statement = con.createStatement();

            ResultSet result = statement.executeQuery("SELECT * FROM medical_tests");

            
            while (result.next()) {
                medicalTests.add(result.getString(1));
            }
            
            return medicalTests;

        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
                statement.close();
            } catch (Exception e) {
            }
        }
    }
    
    public static void AddMedicalTest(String testName){
        PreparedStatement pStatement = null;
        
        try {
            con = DriverManager.getConnection(currentDir);
            pStatement = con.prepareStatement("INSERT INTO medical_tests VALUES(?)");
            pStatement.setString(1, testName);

            pStatement.execute();

        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        } finally {
            try {
                con.close();
                pStatement.close();
            } catch (Exception e) {
            }
        }
    }
}

