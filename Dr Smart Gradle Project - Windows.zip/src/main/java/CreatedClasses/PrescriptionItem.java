/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CreatedClasses;

/**
 *
 * @author Nayanajith
 */
public class PrescriptionItem {
    public String DrugName;
    public String Schedule;
    public String DrugMealRelationship;
    public String Days;
}

