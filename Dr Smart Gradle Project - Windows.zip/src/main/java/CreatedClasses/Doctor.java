/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CreatedClasses;

/**
 *
 * @author Nayanajith
 */
public class Doctor {
    public String DoctorID;
    public String DoctorName;
    public String PhoneNumber;
    public String Email;
    public String DoctorFee;
    
    public Doctor(String doctorID, String doctorName, String phoneNumber, String email, String doctorFee) {
        DoctorID = doctorID;
        DoctorName = doctorName;
        PhoneNumber = phoneNumber;
        Email = email;
        DoctorFee = doctorFee;
    }
}
