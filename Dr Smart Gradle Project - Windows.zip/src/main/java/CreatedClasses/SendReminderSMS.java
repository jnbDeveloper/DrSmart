/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CreatedClasses;

import com.vonage.client.VonageClient;
import com.vonage.client.sms.MessageStatus;
import com.vonage.client.sms.SmsSubmissionResponse;
import com.vonage.client.sms.messages.TextMessage;


/**
 *
 * @author Nayanajith
 */
public class SendReminderSMS {

    public static boolean Send(String phoneNumber, String message) throws Exception {
        MedicalCenterDetails mcd = CommonMethods.GetMedicalCenterDetails();
        
        VonageClient client = VonageClient.builder().apiKey(mcd.APIKey).apiSecret(mcd.APISecret).build();

        TextMessage msg = new TextMessage(
                mcd.MedicalCenterName,          //Title
                phoneNumber,                    //Phone number
                message                         //Message body
        );

        try {
            SmsSubmissionResponse response = client.getSmsClient().submitMessage(msg);

        if (response.getMessages().get(0).getStatus() == MessageStatus.OK) {
            CommonMethods.AddNotification(String.format("SMS sent successful to %s", phoneNumber));
            return true;
        } else {
            CommonMethods.AddNotification(String.format("SMS send fail to %s : %s", phoneNumber, response.getMessages().get(0).getErrorText()));
            return false;
        }
        } catch (Exception e) {
            CommonMethods.AddNotification(String.format("SMS send fail to %s : %s", phoneNumber, e.getMessage()));
            return false;
        }
    }
}
