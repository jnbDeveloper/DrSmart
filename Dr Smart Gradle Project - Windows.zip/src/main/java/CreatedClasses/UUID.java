/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CreatedClasses;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author Nayanajith
 */
public class UUID {

    public static String GetUUID() throws Exception {    
        String OS = System.getProperty("os.name").toLowerCase();
        String command = "";

        if (OS.contains("win")) {
            command = "wmic csproduct get UUID";

            String uuid = "";
            try {
                Process p = Runtime.getRuntime().exec(command);
                BufferedReader inn = new BufferedReader(new InputStreamReader(p.getInputStream()));

                String line = "";
                while ((line = inn.readLine()) != null) {
                    if (!line.equals("")) {
                        uuid = line; 
                    }
                }
                return uuid;
            } catch (Exception e) {
                return uuid;
            }
        } else if (OS.contains("mac")) {
            command = "system_profiler SPHardwareDataType | awk '/UUID/ { print $3; }'";

            String uuid = "";
            
            try {
                Process p = Runtime.getRuntime().exec(command);
                BufferedReader inn = new BufferedReader(new InputStreamReader(p.getInputStream()));

                String line;
                
                while ((line = inn.readLine()) != null) {
                    if (line != null) {
                        if (line.trim().startsWith("Hardware UUID: ")) {
                            uuid = line.replace("Hardware UUID: ", "").trim();
                        }
                    }
                }
                return uuid;
            } catch (Exception e) {
                return uuid;
            }
        }
        else {
            return "";
        }
    }
}
