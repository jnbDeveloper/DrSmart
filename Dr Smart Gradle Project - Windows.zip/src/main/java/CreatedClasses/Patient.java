/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CreatedClasses;

/**
 *
 * @author Nayanajith
 */
public class Patient {
    public String PatientID;
    public String PatientName;
    public String GuardianName;
    public String GuardianPhone;
    public String AgeGroup;
    public String PhoneNumber;
    public String Birthday;
    public String Email;
    public String PostalCode;
    public String Address;
    public String Provider;
    public String Age;
    public String Weight;
    public String Height;
    public String BloodGroup;
    public String BloodPresure;
    public String Gender;
    public String BloodReport;
    public String FamilyHistory;
    public String PreviousDignose;
    public String GotVaccine;
    public String VaccineName;
    public String InjectedDate;
}
